#!/bin/bash
# 더블클릭하면 체스 게임 실행
cd "$(dirname "$0")"
if ! command -v python3 >/dev/null 2>&1; then
  osascript -e 'display dialog "Python 3이 필요합니다. 열리는 페이지에서 설치한 뒤 다시 실행하세요." buttons {"확인"} default button 1'
  open "https://www.python.org/downloads/"
  exit 1
fi
# 매끈한 기물용 Pillow (설치 실패해도 게임은 실행됨)
python3 -c "import PIL" 2>/dev/null || python3 -m pip install --user -q pillow 2>/dev/null || true
python3 chess_game.py
