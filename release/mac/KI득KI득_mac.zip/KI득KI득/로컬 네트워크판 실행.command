#!/bin/bash
set -e
cd "$(dirname "$0")"

if ! command -v python3 >/dev/null 2>&1; then
  osascript -e 'display dialog "Python 3이 필요합니다. Python 공식 사이트에서 설치한 뒤 다시 실행하세요." buttons {"확인"} default button 1'
  open "https://www.python.org/downloads/"
  exit 1
fi

if [ ! -x .venv/bin/python ]; then
  python3 -m venv .venv
fi
if ! .venv/bin/python -c "import aiohttp, qrcode" >/dev/null 2>&1; then
  .venv/bin/python -m pip install -r web/requirements.txt
fi
exec .venv/bin/python web/local_launcher.py
